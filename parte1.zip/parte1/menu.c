
	//Add menu bar after Help
	ProStringToWstring(message_file, "drawing_reuse_menu.txt");
    status = ProMenubarMenuAdd ("Drawing_Reuse", "Drawing_Reuse", "Help", PRO_B_TRUE, message_file);
	if (status != PRO_TK_NO_ERROR)
	{
		WriteLogInteger("ProMenubarMenuAdd Menu Status Error: %i\n", status);
		return (0);
	}


	//Add "Reuse Order Drawing" button to the menu bar
    status = ProCmdActionAdd("Reuse Order Drawing", (uiCmdCmdActFn)DrawingReuse, uiProe2ndImmediate, 
		EasyParam_Access_Default, PRO_B_TRUE, PRO_B_TRUE, &cmd_id);
	if (status != PRO_TK_NO_ERROR)
	{
		WriteLogInteger("ProCmdActionAdd Menu Status Error: %i\n", status);
		return (0);
	}


    status = ProMenubarmenuPushbuttonAdd("Drawing_Reuse", "Reuse Order Drawing", "Reuse Order Drawing",
		"Prototype function in order to reuse drawing", NULL, PRO_B_TRUE, cmd_id, message_file);

	if (status != PRO_TK_NO_ERROR)
	{
		WriteLogInteger("ProMenubarmenuPushbuttonAdd Menu Status Error: %i\n", status);
		return (0);
	}