	
#include <ProUIDialog.h>
#include <ProUIPushbutton.h>
#include <ProUIInputpanel.h>


 
ProCharLine in_string;
ProCharLine out_string;

static void UsrOKAction(
	char *dialog,
	char *component,
	ProAppData data)
{
	wchar_t* wstr;
 
	ProUIInputpanelValueGet(dialog, "InputPanel1", &wstr);
	ProWstringToString(in_string, wstr);

	ProUIInputpanelValueGet(dialog, "InputPanel2", &wstr);
	ProWstringToString(out_string, wstr);
	ProUIDialogExit(dialog, 1);
}

static void UsrCancelAction(
	char *dialog,
	char *component,
	ProAppData data)
{
	ProUIDialogExit(dialog, 0);
}




DialogResult DialogQuery() {

	DialogResult res;
	res.status = PRO_TK_NO_ERROR;
	//Resource tem que estar em TEXT/$lang/RESOURCE

	char *dialog_name = "confirm";
	ProError status = ProUIDialogCreate(dialog_name,"confirm.res");
	WriteLogInteger("init Dialog  Status   %i\n", status);
	res.status = status;
	if (status != PRO_TK_NO_ERROR) return res;

	// Add the buttons

	ProUIPushbuttonActivateActionSet(dialog_name, "OK", UsrOKAction, NULL);
	ProUIPushbuttonActivateActionSet(dialog_name, "Cancel", UsrCancelAction,NULL);

	ProWstringToString(in_string, L"OILC_FOOT_CC0000000.DRW");
	ProWstringToString(out_string, L"BJ1234567");

	ProUIInputpanelValueSet(dialog_name, "InputPanel1", L"OILC_FOOT_CC0000000.DRW");
	ProUIInputpanelValueSet(dialog_name, "InputPanel2", L"BJ1234567");

	int d_status = 0;
	ProUIDialogActivate(dialog_name, &d_status);

     WriteLogString("reader input as     %s\n", in_string);
	 ProUIDialogDestroy(dialog_name);

	if (d_status ==0 ) {
		res.status = PRO_TK_USER_ABORT;
		 
	}
	else { 
		strcpy_s(res.in_string, 80, in_string);
		strcpy_s(res.out_string, 80, out_string);
	}
	return res;
}
	
	
	
	
	
	
	
	
	// Chama o Dialogo 
	
	
	DialogResult dialog_status  = DialogQuery();
	if (dialog_status.status != PRO_TK_NO_ERROR) {
		WriteLogInteger("DialogQuery  %i\n", dialog_status.status);
		return dialog_status.status;
	}
	
	
	
	
	
	
	
	